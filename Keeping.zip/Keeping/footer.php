<?php if (!defined( '__TYPECHO_ROOT_DIR__')) exit; ?>
</div>
</main>
<footer class="footer">
    <div class="copyright">&copy;
<span itemprop="copyrightYear">2018 - 2019</span>

<span class="author" itemprop="copyrightHolder"><a href="<?php $this->options->siteUrl(); ?>"><?php $this->options->title() ?></a> | </span>

<span>Crafted with ❤️ by <a href="" target="_blank"
rel="external nofollow noopener noreffer">Keeping</a> & <a href="http://typecho.org/"
target="_blank" rel="external nofollow noopener noreffer">Typecho</a></span>

        <br />
        <a href="https://www.upyun.com/" target="_blank">
            <img src="<?php $this->options->themeUrl('images/又拍云_logo5.png') ?>" style="width:48px">
        </a>
        <link rel="stylesheet" href="<?php $this->options->themeUrl('js/c41407119fd540ca8be2f3c058b2b3f9.js');?>">
<script async src="<?php $this->options->themeUrl('js/1a8f7b3ed5da49b59f465e8fbf83e1a7.js'); ?>"></script>
<script>window.dataLayer =window.dataLayer ||[];function gtag(){dataLayer.push(arguments);}
gtag('js',new Date());gtag('config','UA-110780416-1');</script>
    </div>
</footer>
<script src='<?php $this->options->themeUrl('js/nprogress.js'); ?>'></script>
<script src='<?php $this->options->themeUrl('js/pjax.min.js'); ?>'></script>
<script src='<?php $this->options->themeUrl('js/vendor_main.min.js'); ?>'></script>
<script>
var pjax = new Pjax({
    elements: 'a[href]:not([href^="#"])',
    cacheBust: false,
    debug: false,
    selectors: ['title', '.wrapper'
    ]
});
document.addEventListener('pjax:send', function () {
    NProgress.start();
});
document.addEventListener('pjax:complete', function () {
    NProgress.done();
});
</script>
</div>
</body>

</html>